const { equal } = require('assert');
const express = require('express'); //import express
//importation de mongoose
const mongoose = require('mongoose');
//permet de séparer chaque attribut valeur
const bodyParser = require('body-parser');  //hadhi takhedh kol valeur ml objet wa7do w tparsi 3lih

//omportation de model user
const User = require('./models/user');

//omportation de model plat
const Plat = require('./models/plat');

//creation d'une application
const app = express();
//prepare response to JSON to send to FE
app.use(bodyParser.json());
//Parse getted body from FE to JSON object
app.use(bodyParser.urlencoded({extented:true}))

//connect to database
mongoose.connect('mongodb://localhost:27017/fullStackJuillet',{
    useNewUrlParser: true,
    useUnifiedTopology: true
});

//     mongoose.connect('mongodb://localhost:27017/fullStackJuillet', {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
// });
// Security configuration
app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader(
        "Access-Control-Allow-Headers",
        "Origin, Accept, Content-Type, X-Requested-with, Authorization"
    );
    res.setHeader(
        "Access-Control-Allow-Methods",
        "GET, POST, DELETE, OPTIONS, PATCH, PUT"
    );
    next();
});

//traitement logique

//CRUD ADMIN

app.get('/admins', (req, res) => { //request response 
    console.log('here into get all admins');
});

app.get('/admins/:id', (req, res) => {
    console.log('here into Get user by id');
});

app.delete('admins/:id', (req, res) => {
    console.log('here into delete user');
});

app.post('/admins', (req, res) => {
    console.log('here into add admin');
    const user = new User({
        firstName:req.body.firstName ,  
        //firstName: partie backend req.body.firstName :hadhi partie frontend ma3nha jebto ml frontend 
        lastName:req.body.lastName,
        email:req.body.email,
        pwd:req.body.pwd,
        phone:req.body.phone,
        role:req.body.role,

    })
    console.log(req.body);
    user.save();
});

app.put('/admins/:id', (req, res) => {
    console.log('here into edit admin');
});

//CRUD CHEF

app.get('/chefs', (req, res) => {
    console.log('here into all chefs');
});

app.get('/chefs/:id', (req, res) => {
    console.log('here into all chefs by ID');
});

app.post('/chefs', (req, res) => {
    console.log('here into add chef');
    const user = new User({
        firstName:req.body.firstName ,  
        lastName:req.body.lastName,
        email:req.body.email,
        pwd:req.body.pwd,
        phone:req.body.phone,
        specialite:req.body.specialite,
        experience:req.body.experience,
        role:req.body.role,

    })
    console.log(req.body);
    user.save();
});

app.put('/chefs/:id', (req, res) => {
    console.log('here into edit chef');
});

app.delete('/chefs/:id', (req, res) => {
    console.log('here into delete chef');
});

//CRUD PLAT

app.get('/plats', (req, res) => {
    console.log('here into all plats');
});

app.get('/plats/:id', (req, res) => {
    console.log('here into all plats by ID');
});

app.post('/plats', (req, res) => {
    console.log('here into add plat');
    const plat = new Plat({
        platName:req.body.platName ,  
        price:req.body.price,
        desc:req.body.desc,
    })
    console.log(req.body);
    plat.save();
});

app.put('/plats/:id', (req, res) => {
    console.log('here into edit plat');
});

app.delete('/chefs/:id', (req, res) => {
    console.log('here into delete plat');
});
module.exports = app;